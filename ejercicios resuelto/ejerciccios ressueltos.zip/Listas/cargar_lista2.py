numeros=[0,0,0,0,0,0,0]
for i in range(0,7,1):
    numeros[i] = int(input('ingrese un número: '))
for i in range(0,6,1):
    print (numeros[i])