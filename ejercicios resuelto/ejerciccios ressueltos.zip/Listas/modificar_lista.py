numeros = [17, 123]
numeros[1] = 5 #modifica la posición 1 de la lista = 123 por 5
print(numeros)

