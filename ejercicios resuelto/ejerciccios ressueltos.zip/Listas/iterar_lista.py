lista = [54, 4, 19, 21]
for elemento in lista:
    print(elemento)
print(lista)
