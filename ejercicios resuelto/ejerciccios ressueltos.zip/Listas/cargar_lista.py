lista=[0,0,0,0]
print(len(lista))
for i in range(len(lista)):
    lista[i]=input("ingrese el valor ")
print(lista)