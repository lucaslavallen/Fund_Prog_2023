cuadrados = []
for x in range(11):
    cuadrados.append(x**2)
print(cuadrados)