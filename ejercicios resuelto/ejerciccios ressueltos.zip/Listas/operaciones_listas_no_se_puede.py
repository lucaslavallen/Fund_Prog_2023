lista=['rossina','maría','elias','javier','python']
x=input('ingrese elemento a buscar: ')
if x in lista:    #esto tampoco se puede
    print(x, 'está')
else: print(x, 'no está')