lista = [5, 9, 10]
for i in range(0, len(lista)):
    print(lista[i])
print(lista)