matriz=[[0,0,0],[0,0,0,]]
for i in range(len(matriz)):
    for j in range(len(matriz[0])):
	    matriz[i][j]=int(input('ingrese el elemento: '))
print(matriz)