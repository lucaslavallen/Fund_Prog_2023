# ejercicio 1 - guia tp secuencia	Leer tres números de a una por vez, calcular su suma y su producto
n1=int(input ("ingrese el primer número: "))
n2=int(input ("ingrese el segundo número: "))
n3=int(input ("ingrese el tercer número: "))
suma=n1+n2+n3
print("el resultado de la suma es:", suma)