a=
b=2
if a>0 and b>0:
    print('ambas variables son positivas')
elif a<0 and b<0:
    print('ambas variables son negativas')
else: print('ambas variables ambas o una valen cero')