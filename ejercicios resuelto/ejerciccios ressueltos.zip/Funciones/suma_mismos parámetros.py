def sumados(a, b):
    suma = a + b
    return suma

a=int(input ("ingrese num 1: "))
b=int(input ("ingrese num 2: "))
x = sumados(a,b)
print(x)

