lista = [524, 54, 219, 721]
lista.sort()
print(lista)