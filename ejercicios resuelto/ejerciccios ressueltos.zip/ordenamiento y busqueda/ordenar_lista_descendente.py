lista = [223, 81, 92]
lista.sort(reverse=True)
print(lista)