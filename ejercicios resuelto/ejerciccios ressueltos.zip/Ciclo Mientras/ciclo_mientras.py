#ingresar una lista de números que culmina con cero
c=0
x=int(input ("ingrese primer número: "))
while x!=0:
    c=c+1
    x=int(input ("ingrese primer número: "))
print("la cantidad de números que se ingresaron fue: ",c)